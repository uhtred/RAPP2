``divisibleby``
===============

``divisibleby`` checks if a variable is divisible by a number:

.. code-block:: jinja

    {% if loop.index is divisibleby(3) %}
        ...
    {% endif %}
